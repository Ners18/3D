import logo from "./logo.svg";

import github from "./github.png";
import menu from "./menu.svg";
import close from "./close.svg";

import dimension from "./tech/979.gif";
import dolargif from "./tech/971.gif";
import Poundgif from "./tech/983.gif";

import threejs from "./tech/threejs.svg";


import orangeup from "./tech/orangeup.png"
import orangeupother from "./tech/orangeupother.png"


import carrent from "./carrent.png";
import jobit from "./jobit.png";
import tripguide from "./tripguide.png";
import dollar from "./tech/dollar.png"
import Euro from "./tech/Euro.png";
import yen from "./tech/yen.png";
import Russian from "./tech/Russian.png";
import Pound1 from "./tech/Pound1.png";
import swiss from "./tech/swiss.png";
import tl from "./tech/tl.png";
import yuan from "./tech/yuan.png";
import australian from "./tech/australian.png";
import indian from "./tech/indian.png";
import canadian from "./tech/canadian.png";
import south from "./tech/south.png"
export {
  
  logo,
  
  github,
  menu,
  close,
  threejs,
 
  carrent,
  jobit,
  tripguide,
  dollar,
  Euro,
  yen,
  Russian,
  Pound1,
  swiss,
  tl,
  yuan,
  australian,
  indian,
  canadian,
  south,
  dimension,
  dolargif,
  Poundgif,
  orangeup,
  orangeupother,
};
